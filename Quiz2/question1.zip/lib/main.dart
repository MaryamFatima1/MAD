import 'package:flutter/material.dart';

void main() {
  runApp(MaterialApp(
    initialRoute: '/page1',
    routes: {
      '/page1': (context) => Page1(),
      '/page2': (context) => Page2(),
    },
  ));
}

class Page1 extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Page 1'),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Hero(
              tag: 'fly',
              child: Icon(
                Icons.favorite,
                size: 100,
                color: Colors.red,
              ),
            ),
            ElevatedButton(
              onPressed: () {
                Navigator.pushNamed(context, '/page2');
              },
              child: Text('Go to Page 2'),
            ),
          ],
        ),
      ),
    );
  }
}

class Page2 extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Page 2'),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Hero(
              tag: 'fly',
              child: Icon(
                Icons.favorite,
                size: 100,
                color: Colors.red,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
