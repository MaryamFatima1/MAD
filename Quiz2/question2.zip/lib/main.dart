import 'package:flutter/material.dart';

void main() {
  runApp(EmailApp());
}

class EmailApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: LoginPage(),
    );
  }
}

class LoginPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(20.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(
                Icons.email,
                size: 80, // Icon size
                color: Colors.blue, // Icon color
              ),
              SizedBox(height: 20),
              Text(
                "Email Login",
                style: TextStyle(
                  fontSize: 24, // Font size
                  fontFamily: 'Arial', // Font family
                  color: Colors.black, // Text color
                ),
              ),
              SizedBox(height: 20),
              TextFormField(
                decoration: InputDecoration(
                  labelText: "Email",
                  // Add custom styling as needed
                ),
              ),
              TextFormField(
                obscureText: true, // Password field
                decoration: InputDecoration(
                  labelText: "Password",
                  // Add custom styling as needed
                ),
              ),
              SizedBox(height: 20),
              ElevatedButton(
                onPressed: () {
                  // Add login functionality
                  // Navigate to the account screen on success
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => AccountScreen(),
                    ),
                  );
                },
                child: Text("Login"),
                style: ElevatedButton.styleFrom(
                  primary: Colors.blue, // Button background color
                  padding: EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class AccountScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("My Account"),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              Icons.account_circle,
              size: 100, // Icon size
              color: Colors.blue, // Icon color
            ),
            SizedBox(height: 20),
            Text(
              "Welcome to Your Account",
              style: TextStyle(
                fontSize: 24, // Font size
                fontFamily: 'Arial', // Font family
                color: Colors.black, // Text color
              ),
            ),
          ],
        ),
      ),
    );
  }
}
